# synthlog

## running synthlog

1. Install synthlog with `pip install -e .` (from the synthlog directory).
2. Run `synthlog examples/synthlog/load_spreadsheet.pl`.