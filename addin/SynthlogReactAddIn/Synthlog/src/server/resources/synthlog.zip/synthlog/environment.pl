:- use_module('spreadsheet.py').
:- use_module(library(collect)).
:- use_module(library(aggregate)).
:- use_module(library(lists)).
list(X,X).
:- use_module('../synthlog/utils.py').
:- consult('../synthlog/predict.pl').