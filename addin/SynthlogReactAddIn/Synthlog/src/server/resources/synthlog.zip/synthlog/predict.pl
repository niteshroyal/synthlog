:- use_module('../synthlog/predict.py').
Prob::predict(S, Pred, C, X) :- predict(S, Pred, C, X, Prob).