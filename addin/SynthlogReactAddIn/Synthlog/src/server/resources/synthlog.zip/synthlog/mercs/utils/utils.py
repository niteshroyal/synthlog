# Tiny utilities
